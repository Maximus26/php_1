<?php

require_once __DIR__ . '/../config/config.php';
$menu_arr = [
	[
		'title' => 'Главная',
		'link' => '/'
	],
	[
		'title' => 'Контакты',
		'link' => '/contacts.php'
	],
	[
		'title' => 'Галерея',
		'link' => '/gallery.php'
	]
];